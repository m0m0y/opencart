<?php
// Text
$_['text_subject']  = '%s - Affiliate Credit';
$_['text_received'] = 'You have received %s credit!';
$_['text_total']    = 'Your total amount of credit is now %s.';
$_['text_credit']   = 'Your account credit can deducted from your next purchase.';